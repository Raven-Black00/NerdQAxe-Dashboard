
# Step 2: Read the latest valhalla_flasher.py (file:5 is the one with gold labels already)
with open("./valhalla_flasher.py", "r", encoding="utf-8") as f:
    src = f.read()

print(f"Source length: {len(src)} chars")
print("Has gold labels:", "Programming by Alan Klusacek" in src)
print("Has iconbitmap:", "iconbitmap" in src)
print("Has img_path resource_path:", "img_path = resource_path" in src)
