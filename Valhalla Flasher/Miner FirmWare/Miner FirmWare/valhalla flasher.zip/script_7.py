
# 4. Replace iconbitmap() to extract ICO to a temp file
old_icon = (
    'try:\n'
    '            self.root.iconbitmap(resource_path(os.path.join("assets", "valhalla.ico")))\n'
    '        except Exception:\n'
    '            pass'
)
new_icon = (
    'try:\n'
    '            _ico_tmp = _tempfile.NamedTemporaryFile(suffix=".ico", delete=False)\n'
    '            _ico_tmp.write(_asset_bytes(_VALHALLA_ICO_B64))\n'
    '            _ico_tmp.close()\n'
    '            self.root.iconbitmap(_ico_tmp.name)\n'
    '        except Exception:\n'
    '            pass'
)

if old_icon in new_src:
    new_src = new_src.replace(old_icon, new_icon)
    print("iconbitmap patched.")
else:
    idx = new_src.find('iconbitmap')
    print(f"iconbitmap at {idx}")
    print(repr(new_src[idx-20:idx+100]))
