
# Now build the fully self-contained single-file version
# Strategy:
#  1. Add base64 asset constants at the top (after imports)
#  2. Replace resource_path() with a get_asset_bytes() helper that returns from base64
#  3. Replace Image.open(img_path) with Image.open(io.BytesIO(get_asset_bytes("triquetra")))
#  4. Replace iconbitmap() call to write ICO to a temp file (tkinter requires file path for iconbitmap)
#  5. Remove resource_path() function (no longer needed)

# ── Wrap b64 strings nicely ──
def wrap_b64(b64str, var_name, indent=0):
    pad = " " * indent
    chunk = 76
    lines = [b64str[i:i+chunk] for i in range(0, len(b64str), chunk)]
    out = f'{pad}{var_name} = (\n'
    for line in lines:
        out += f'{pad}    "{line}"\n'
    out += f'{pad})\n'
    return out

# ── Build the asset block to inject after imports ──
asset_block = '''
# ── Embedded assets (base64) — no external files needed ──────────
import base64
import io as _io
import tempfile as _tempfile

_TRIQUETRA_PNG_B64 = (
''' 

# chunk the png b64
chunk = 76
lines = [png_b64[i:i+chunk] for i in range(0, len(png_b64), chunk)]
for line in lines:
    asset_block += f'    "{line}"\n'
asset_block += ')\n\n'

asset_block += '_VALHALLA_ICO_B64 = (\n'
lines = [ico_b64[i:i+chunk] for i in range(0, len(ico_b64), chunk)]
for line in lines:
    asset_block += f'    "{line}"\n'
asset_block += ')\n\n'

asset_block += '''def _asset_bytes(b64data: str) -> bytes:
    return base64.b64decode(b64data)

'''

print(asset_block[:300])
print(f"Asset block total length: {len(asset_block)}")
