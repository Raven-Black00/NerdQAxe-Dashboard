
# Step 1: Generate the triquetra PNG and valhalla ICO programmatically using Pillow/numpy
# Then base64-embed them into the script

import numpy as np
from PIL import Image, ImageDraw, ImageOps
import math, io, base64

# ── Generate triquetra (trinity knot) as a PNG with transparency ──
SIZE = 256
img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)

cx, cy = SIZE // 2, SIZE // 2
r = 80   # radius of each circle arc
offset = 28  # distance each circle center is offset from cx,cy

# Three overlapping circles forming a triquetra
centers = [
    (cx,          cy - offset),               # top
    (cx - int(offset * math.sqrt(3)/2), cy + offset // 2),  # bottom-left
    (cx + int(offset * math.sqrt(3)/2), cy + offset // 2),  # bottom-right
]

# Draw thick arcs for each lobe
stroke = 14
for i, (ox, oy) in enumerate(centers):
    bbox = [ox - r, oy - r, ox + r, oy + r]
    draw.arc(bbox, start=0, end=360, fill=(20, 14, 8, 255), width=stroke)

# Draw the three main arcs that form the knot shape
# Use a cleaner approach: draw 3 arcs with gaps to simulate weaving
for i, (ox, oy) in enumerate(centers):
    base_angle = i * 120
    bbox = [ox - r, oy - r, ox + r, oy + r]
    # Draw the visible arc portion
    draw.arc(bbox, start=base_angle + 30, end=base_angle + 270, fill=(20, 14, 8, 255), width=stroke)

# Add a small circle in center
draw.ellipse([cx-10, cy-10, cx+10, cy+10], fill=(20, 14, 8, 255))

# Save PNG to bytes
png_buf = io.BytesIO()
img.save(png_buf, format="PNG")
png_bytes = png_buf.getvalue()
print(f"PNG size: {len(png_bytes)} bytes")

# ── Generate valhalla.ico ──
# Create a simple rune-like icon
ico_img = Image.new("RGBA", (64, 64), (15, 10, 6, 255))
d = ImageDraw.Draw(ico_img)
# Draw a simple Norse-style Vegvisir/compass shape
cx2, cy2 = 32, 32
# Outer circle
d.ellipse([4, 4, 60, 60], outline=(212, 167, 79, 255), width=3)
# 8 spokes
for angle in range(0, 360, 45):
    rad = math.radians(angle)
    x1 = cx2 + int(8 * math.cos(rad))
    y1 = cy2 + int(8 * math.sin(rad))
    x2 = cx2 + int(26 * math.cos(rad))
    y2 = cy2 + int(26 * math.sin(rad))
    d.line([x1, y1, x2, y2], fill=(212, 167, 79, 255), width=2)
# Inner dot
d.ellipse([28, 28, 36, 36], fill=(212, 167, 79, 255))

ico_buf = io.BytesIO()
ico_img.save(ico_buf, format="ICO", sizes=[(32, 32), (16, 16)])
ico_bytes = ico_buf.getvalue()
print(f"ICO size: {len(ico_bytes)} bytes")

# ── Base64 encode both ──
png_b64 = base64.b64encode(png_bytes).decode("ascii")
ico_b64 = base64.b64encode(ico_bytes).decode("ascii")
print(f"PNG b64 length: {len(png_b64)}")
print(f"ICO b64 length: {len(ico_b64)}")
