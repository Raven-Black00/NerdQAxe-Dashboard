
# Now inject asset block and patch the source

new_src = src

# 1. Inject asset block after the last import line (before resource_path def)
inject_after = 'import tkinter as tk\nfrom tkinter import ttk, filedialog, messagebox\n'
if inject_after in new_src:
    new_src = new_src.replace(inject_after, inject_after + '\n' + asset_block, 1)
    print("Asset block injected.")
else:
    print("Inject point not found!")

# 2. Remove resource_path function entirely
import re
# Match the function def through its return statement
rp_pattern = r'\ndef resource_path\(relative: str\) -> str:\n    base = getattr\(sys, \"_MEIPASS\", os\.path\.dirname\(os\.path\.abspath\(__file__\)\)\)\n    return os\.path\.join\(base, relative\)\n'
if re.search(rp_pattern, new_src):
    new_src = re.sub(rp_pattern, '\n', new_src)
    print("resource_path removed.")
else:
    print("resource_path pattern not found — trying simpler match")
    # Try simpler
    idx = new_src.find('\ndef resource_path(')
    end = new_src.find('\n\n', idx+1)
    print(repr(new_src[idx:end+2]))
