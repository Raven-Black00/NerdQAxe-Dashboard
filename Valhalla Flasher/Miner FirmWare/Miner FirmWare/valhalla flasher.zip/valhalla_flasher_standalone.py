#!/usr/bin/env python3
"""
Valhalla Flasher — NerdQaxe++ Hydro Edition  v2.1.0
ESP32-S3 firmware flasher with Viking soul.

Two flash modes:
  SERIAL  — USB/COM port via esptool (first-time or recovery flash)
  NETWORK — OTA over IP via AxeOS HTTP API (normal updates over WiFi/LAN)
"""

import os
import sys
import time
import queue
import threading
import subprocess
import urllib.request
import urllib.error
import tkinter as tk
from tkinter import ttk, filedialog, messagebox


# ── Embedded assets (base64) — no external files needed ──────────
import base64
import io as _io
import tempfile as _tempfile

_TRIQUETRA_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAALOUlEQVR4nO3dvXLcSAyF0daWA0eO"
    "/P5PqEiRMm0gszQakTNN9t+9wHeyrdpao9HAJbUeSaUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAIAVXlYXgLH+/vn90frfeH17Z06C4mID6LHkVxEO3rg8QysX/hkCwQuXZUB54Z8hELRxOaKc"
    "l/4IYaCHCxEScemPEAYauAQBmRb/HkGwFs1fKPPi3yMI1qDpC7D4xwiCuWj2RCx+PYJgDpo8AYt/"
    "HUEwFs0diMXvhyAY47/VBUTF8vdFP8cgVTtjUMfjbaAfGtmR4vL3WJao5wIB0IXCgqxYiKznjoTm"
    "NVq1BIqDTy/80LgGswfeadDpjQeadsHM4Y4w2PRLF806adYwRxxkeqeHRp0wY4AzDC991EGTKo0e"
    "2owDS0/Xo0EVRg4qQ0p/V6I5T4waTgbzJ3o9H415YMRAMozP0fd5+GagAwzhOiP6pPCpRUUEwA6W"
    "fz1CYA6G8k7vIWHx23En4/AGcINB09S7j7wJfCEA/mH5tRECY/xaXUA0LP44W29Z3n54Ayj9Borl"
    "n6NXnwkSAoDlN0UI9JE6AFh+b4RAu9QB0APLvxb9b5M2AHqkPsOnIeoPPp0hZQCw/PEQAtekDAAA"
    "n9IFAE//uHgLOC9VALD88REC56QKgFYsvwfuqV6aAMiU6miXZV74XoBKo54q7l+WqNb/+vb+kmWJ"
    "W6R4VWodhNYBXTmI7l8Tr+599C8nQh9u0zIEVwZA+clTcx73+u/Nvn8noQ9XypwngPLCPOP+qjzj"
    "fiKHQNiDbUalv/PSRDXqvggAU72Tn6X30fvuooZAmr8GPOv2wv/++f3B8nu5v7OoC9wqbAD0WFgW"
    "31+vO4w6B2EDoFXUC8+K+9wXMgC4bIwQca5CBgCAOgQAkFi4AIj4mgYd0eYrXAAAqMd3Ay525u+n"
    "nZ4+Uc8VTagPRygPUssHUZTP9UzUc0f5YFGIQ2yUBoZfWvElYi8IAEGrB4TfYHssWm8IAEErhmLE"
    "IMw8x+xvB3bv14YAEDN7CJR/RFiNvfpX/tk9RJmBmewPsHEf3lLmnEHlB5y497EUAkDK6EsffdmK"
    "9SvWdIZ7/TPYH6CUsRc945LV61ev7xn3+keyLr6UcZc762Kd6neqdY97/SPYFl7KmAudeZmu9bvW"
    "vXGvvyfb7wVwv0Tn+p3eLva419+TZQA4L08p/vWP+vMIgfnsXlt6N3n24rjXv8f9TO71t7B6A3C/"
    "KPf6j7h/zNe9/hY2AeDU1D1Rl3+TeYn2uNRvEwC9qS1Qrde39xfV2pVre8a17lYWAeCSpkd61e8y"
    "pBG//fcKh/rlA8ChiY9kW/4NIfBJvX7pAFBv3jNZl39DCHxSrl86AOC7/Bv3+qOTDQDl1KzRo/4o"
    "y6P+DUkzqNYvGQCqzarF8v9ECGjWLxkAAOaQCwDFlDyDp/8x3gL06pcKALXmnMXyP0cIaNUvFQDZ"
    "RV/+TZZzOpAJAKVUvMK9fjfu/VapXyYAssv2VMx2XlUSAaCShle11p91GVrPnX1uepAIgMyyLv8m"
    "+/lXWx4ACinYwr1+d+79X13/8gBo4f70cK+/F/c+ONe/NABW/r15jz97dXrj08q7dP9cg+0bgHPq"
    "luJff2/u/XCtf1kAuD893euPxv0+VtVv+QbgmrYb9/pHce+LY/1LAoC0xgju97Kifrs3AMeUveVe"
    "/2ju/XGr3y4AenJ/YqCPzHMwPQBamn2Uri6/18/t6bBKS58Ufr+gS/2lJH8DALL7tbqAWu5PT6X6"
    "Hz1lVOp8fXt/cX41d6l/6huAYkPO1KRY/xl///z+eHaGmn9HnfudzqwpzJcAKk8uVWeHSnExlESZ"
    "N4sAcG/26vqvLvPqEFjdt1YO9VsEwGirB32k1rPRm9imBYB7sx3r71Vz5rOvMqt++TeAM69Riq9c"
    "ijU5Ueyf+0zekg+AWdyfGPd6n4f+xEQAAIlNCQCFj2fWOKqTp4WnEffp8rHzWtJvAOpfPz3jXr8K"
    "9z4q1y8dACvwtI+N+/0uZAAoJy58RZyrkAHQiqdETNzrT2EDIGJan9H7/PQz5vnDBkArnhaxcJ/7"
    "hgfAyl+4sPKXNig8MXrV4HyWlb98psd/Y3Rw8QbwQISnRuvwKix/qwj3OEr4AIgwwK2u9oDexe9B"
    "+ADAp7ODHH3w8SlFADDMn17f3l+e9aLm38kiQx9sfigo+skw2KiT4g2gFIYe52SZlzQBAOCnVAGQ"
    "JdXRJtOcpAqAUnJdLs7LNh/pAgDAl5QBkC3lUSfjXKQMgFJyXjaOZZ2HtAEAIHkAZE19fJd5DlIH"
    "QCm5Lx/cf/oAKIUhyIp7nxAAqj8IYTT3+tW491P1B8vwBvAPT4NcuO9PBMCN3kPh/tRS0buPLP8X"
    "AuDOiBAgCK4Z0TuW/zsCYMeIISEEzhnRL5b/JwLgACGwDss/j3QArF6YUSGw+lyqRvVm9fIr3/eU"
    "AFh9AS1G1U4QfBnZC2bvMek3ABUjLyJzEIw+u/Pyz8IPBRWxLUKGoc0aeIrk3wCyDUvkN4LIZzui"
    "ft5pAeD+ZJtdf6RlWXEW5q0OXwKIu10cp6GOEl7RWQTA3z+/P5yGfxT1MGDpv3Poh0UA4Kf74VoR"
    "CA4Djsdshkbliec29D36lvHMPTjMus0bAF8GXOO2vFG49F3+rwEBjDM9AFqe4gqpyluINoX7aZnT"
    "2fXzBgAkZhcACm8BwBG3+VwSAAqvaS3c64/K/V5W1G/3BlCKX8rucR/W3iL0w3EulwWA+4X3qP/1"
    "7f3FvQ+tevXAvY+r6rd8AyjFM21v3X+s132Az7o/c6T7dLL0g0Cvb+8vro0rpX/9kRZiz6iQcw/P"
    "lfXbfBJwj/unAx/VHyUMau7H+XyleNe/PAB4C6j7M27/WblfswPZ+QFQyvr6lwdAq8hvAUeUAqG1"
    "98phVsO9fpnFaW3k6hBQrb/HgKrWxp23s38D2GR8E6ih2hP3J6d7/RuZvwZUHdRa7vW7ce+3Sv0y"
    "AdCDeyq711/L/Zzu9d+SCgD3n17jXv8Myv9PooZ7/fekAqAU/yVyr38k9+Vxr3+PXAAAmEcyANyf"
    "ou71j+D+9HSv/4hkAJTiv0Tu9ffkvjzu9T8iGwC9uC8R9a/lXv8z0gHQKzVXXaJ7/a161b3q6ele"
    "fw3pACjFf4nc67/KfXnc668lHwCl+C+Re/1nuS+Pe/1nhPlegFrb5Tpczh7l+l0C6oh7/VdYvAGU"
    "0n/g3X9fvdqw9q5ndsC513+VTQCU4r9E7vUfcV8e9/pb2BR6a8Tgz7w09/o37udwr78HqzeAzYgm"
    "z3yautc/6s9j+eezDIBS/JfIuX735XGvvyfLom+NGvpZF+pUv1Ote9zrH8G28Fsjn3wzLle9fvX6"
    "nnGvfyTr4m/N/tHcvSnWr1jTGe71z2B/gFszvgYeeekq9avUcZV7/TOFOMStWf8jTPVHZdfaq5/e"
    "1Ymy/KUEDIBS+L/5Z8z+zUwR+jXrz5oh1GHu8Uk/He69ibb4m5CHusV3AK7n3ouoy19KggAoRWOJ"
    "WoZIof6r3M8deflLSRIAG4WBundmwBTrP+J+ruiLv0lxyFuKwwYtWZa/lIQBsCEIcC/T4m9svxmo"
    "VcbLxrGs85Dy0Pd4G8gr6+JvUh/+HkGQR/bF39CEHQRBXCz+dzTjAYIgDhZ/H02pQBD4YvEfozkn"
    "EAQ+WPw6NOkiwkAPS38eDevAOQxmfztwbyx9G5o3gPJCqfxEoKtY+L5o5gQrF0r9h4I+w8KPRXMX"
    "67FcK5fEvX4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "OPQ/8FtCoP96ZOMAAAAASUVORK5CYII="
)

_VALHALLA_ICO_B64 = (
    "AAABAAIAEBAAAAAAIABzAwAAJgAAACAgAAAAACAAzAgAAJkDAACJUE5HDQoaCgAAAA1JSERSAAAA"
    "EAAAABAIBgAAAB/z/2EAAAM6SURBVHicTZNLTFxlGIaf/59zGWbODIdhEBCmQwZbhCJaG7QsLBVc"
    "FA2pYrDG2riyRhdomhpddlGNSePGxMR0YWMXjYlNvMUFiW0iajRtBUFbL6CAMVBaOtzmwsycOZ+L"
    "gcZv9W3e7/K+eVR1yBK2KhBQ5Atl8kWPmGNT69oopcjkSizczmFqTSRkUvbvSDC2G60VaxtFko0O"
    "RwZSNMSChEMmCljPFimUhAsX57h8bZlIyEQpEAFVHbJE68qW/ocaGe5v4dLVRUZ/XGBvWy0CfDe5"
    "xP499Qw+kuDa36uc/XIGy9AogFjElgBKDu5rkvFzg9LVWiOAaJQ83tMsT/Q0i0YJIFWWIZ+f7pM3"
    "jnaKRknMsUXnC2WSjQ7D/S28+PYPDPe30J508RG0VqAABdUhizdf6OSts1PEokEO9jSxmi2i80WP"
    "IwMpLl5Z5Kfflzk/Osuxp3aSbHDwyj4ApqF5/ehuvp+8xeXry5z76i+e7E0QtAIQc2x5/8Q+iUVs"
    "UVun3l0bkpHhdknUhaU5HpZXD3fIgT0NAki0yhJA3h3plu72uBhx1yYcMujuiGMEFEopPM/n02/+"
    "4cTzu+lIuZw8M8n8Yob7W2P4IqxlTfIFj2SDg6G23txOVkQIaIXvCx0pl1STw63VTXq66qirsfE8"
    "IVfwSNSHufrbbYyNrMdapsTY+BLFUhkfARSvHW7n5JlJltc26Wx1uXJ9mbkbGapMg3zJY2ciynq2"
    "hF5I5yh5PgcerAfADVuceukBpqZXmF/M0HVPDVMzK4w8286uRJSyL+y4y6Gl0eHnP9NoM6D55Os5"
    "BvcniDomx5/rYGziJpfGF6mttqlzg8z8u84HF/7g5aE2YtUWT/clGZtYIr1RqKSgUfLK0L3y2ek+"
    "2dsWv+P2fakaOXZol1SZhgSUlng0KB+f6pX3jj8sIdsQN2yJUfaFSMjkwy+miYRNnnksSaHo8evs"
    "KivrJtm8R77kkax3GHp0BzfTm7zz0S8AKFSFhW0w1nMlBnqaONSbIJv3yG1W3J6/kWFHg8O3E0uc"
    "H51FAbYVwPelMuD/OK9sFAmaATpbXZKNYbyysJYpMTmdJr1RwA1bKBS+VGT/AXPEWTR7Px+IAAAA"
    "AElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAIk0lEQVR4nJ2Xe2xX"
    "5RnHP+97br9Lr7SljCKSoSJSqkBogVFkDMVLTFCCYKYZBuOGOqNTHFrUZaIOLzG4ON1wURGmWZSw"
    "TYaAVCUwWi4yJsQJAzcDLbdeaH/0dznnvM/++PVXWqCM7E3e5CTnnPf7zfN8n+/zvKow5goXubRW"
    "WFrhB4YgFJTqfiGAAs/RAIRGkIs81b5YYAQSXT6+McRcm4K4k8PFGBCEE6dSAORFHFxHYy6CyAUJ"
    "KAUKRaLLJxRh+vjvMPryYsaOKGHKmHJOtqdQSpEfs0mmQ95f/w1tiQyr67+lubWLvIiDY2eJ9IvR"
    "XwosSxGGQioTMLFqIA/cfiVTrikn7Ru27jnOlj3HmD5+MEaET3cdpTDucPt1wxhYHKE94fPmmgOs"
    "WneI1lNp8mI2QXh+EuclYFmKztM+WiteXVjNzClDqd/ZzKadzWzY1kRbR4bOlE/dj0YD8Ow7X+Jo"
    "TTRiMe7KEq4dO4hZ0y7FthQPvridjTubKIq7AOempDDmSu89IM8T19JSM6pM1rwwTY6vnyM31FSI"
    "VkoAiXuOlOR7YltKnrl3jCy5d4zYlpKBhREpiDriWFoAGZDvyYqnJ8vx9XPk4TtGSXHclfyoI0Xx"
    "vnh9NGBbio6kz9gRJfz55Wns2d/K9Q9sZO/BdoriLkplFQ4QhIKIIN3PoRGUUuRFHbSGZDrk/qWN"
    "3HXTcBbPr2LksALuW9pIQcwh7BUG3VtwQShopXh83mj+vr8VI1BS6BEaQescaL96AsAYwRhwLE0Q"
    "CsOH5LF8zX6mVw/muurBtCcy2Jbq+f4MARTJTMirj1Qz6eoyHlu2ixdX7OWdpyczo2YwJzvSOLY6"
    "L2jvpbUiCA3JdMiqZ2q5Ymghy97/ig0NTbz9i0nUVJaRSAVYWp0hYGlFIu0zqbKMW6cO5a4nt7Dv"
    "UDubdjVzz5K/8cbjE7ihpuJ/ksiBpzOG956dAsCsRZ+R8Q0PvbKd7ftaWHjnKMIwm7oeAiKCCYWf"
    "zhlJ/Y6jbNzRREHcobQgwseNR/jJ8w19SNi27hVu6Rd8bt1mPEcTcS2CUFj69l7GX1XC5KpyOrp8"
    "LEuhtYbT6YAfjB9M7ZiBfLKjGSFrs35gKC3w+pC4ccIQjrUlAciLOeTFHAD8UPqA31G3Gc/V2JbG"
    "D7Luue9QO0dbkiyYfQWxiIUJBW1pRSYwjL6siIxv2LCtiZjr9KjdD6SHxIJfNfLaYzXM/v4wHFtT"
    "v/MoGxqb8ByLTCbkvSVTUGeB5yLk2IpTyQxrtx6helQptsqKVPuBEI84jLuyhC17jtN+OkPE01ha"
    "YVvZbQTKi6OsazjCz3+9i5snD8GEsH7bEXZ+1ULaD1leNwmtYe7izUQ8jdMNrlS2wgSwtWbrnuNk"
    "/JBxI0vIhAbiniPlRTE5/NFsmX/L5UL22363QomtlVx9+QD543NTZfe7t8iC20bIjJoKKSuMimtb"
    "kh91JO713XkRR6KuLXHXkf0f3Cp186oEkG5NCyfaUtxSewmDSqNEXAs5q4GEAvlRm/qdzaxvbKLu"
    "7tHUXjOQlvY0i+dXMefxzbQn0lSUxgiMcHat5HwmHrFRCrpSAdDdDZVSKAXmIpp4EAqFMZfLLimg"
    "5VSaZDqgWFwmVJay++sWfls3kWi36tV5KjY0EHXtHkOzc+WUH3f4pLGZ36z+5wUJeJYmHRp+t3o/"
    "T95zNUX5LgePdPLu2kOkMoYfP7ctC372jwrCUPAciw2vTcfujr0N2Q6VTIWUFHp4jkVh7EwVQDb5"
    "llYEoZBKh6x6ajIr1h5kbt3n1IwqY8XagxQXuFw1vIhPv2imMOae035zKSjOdzEGMr5BAdpzNSc7"
    "k7y/4d/Mnn4pnm2RzBhCIwSh9Ph/KhNyOhmw8pe1xCIWuw+00vCPE7z+wde0dqSpKIvx+8WTuHHC"
    "EE51ZYh5FralcOzsjrialB8wc+pQLEvx4aZviXlOzgmhvTPNwAERxo0sIe0H6O4Enu1wSsGcJz6n"
    "vTNDRVmM1S9MpaIsRv0Xzdz/QiOvL6rhhpoKTnSkcGyFSPb8nAAnji4j0eWT8UM0oEMj5EUcPqz/"
    "llMJn6ljy/EDg9b922vEtfEci9AIUc/CmKww1zUcPse2HTsr8MAIxXke144tZ+Vfv6ElkcZxNVok"
    "O802t3bx5poDzJp2KUVxj65USGj6s1fV43C5XAeh9Ns7XMcikfSZPX0YiS6fVesOEXVtjJFsCnJR"
    "WLnuEJalWPbo+Oz47YfZsHOWvfYq196lFoTn9o6bJw3heHuSGTUVLJpXyVt/OUhzWxcRRyPSqwoc"
    "W9PamebBl7azakktd940nOFD8nFtzaxFn/Xx9vPVd2717h33L23klZ+Nx3U0T9xdxcbGJpb/aT+F"
    "MbenynoGEmOEvIjNxh1NPP/WlyyeX0UyFTC37nNsrYg41gXH694rCIVBxVHWbjvMwld3seyRagAe"
    "enkHGT+rr1wQde8fQyMUxV3e/uhfrN1ymB/e+F1efng8RoTWzgwidPdwheoV/tyzbWUFF4bC0bYk"
    "M6orWDy/imOtKZ56YzeJpE/UtTDmDGafoVSEngPuW9rA9TWDeevp71FRGmPpu3vZd6iNts40jqWx"
    "tD4jQCMEgXAylSbm2gwo8Lhn5hUsmlfJxoYmHnplB4nTPhHP6mNw5xDIkdBaURBz+HjbEWYurOfR"
    "Oyv5wzO1HGtNsnbLEbbuOU7DvhPEI1klRxyL4gKXmVOHM3F0GVPGDiLR5fPiir0sX3OATGCIRexz"
    "wOECNyPIhjvR5RMaoXZMOQtuG0F1ZWlPHkER9SySqRAjkp0tkwEr1x1k1bpvaG7tojDmopXqt9Fd"
    "kAB0X0yBjkSGaMTGcTTjRgygurKMZCpERLCt7FT14ab/kPYNLR1pYp5NxNV9BtD/i0BPNLQiNNJt"
    "TiF+byV1r7hno5S66JsxwH8B9U5ne/rGBncAAAAASUVORK5CYII="
)

def _asset_bytes(b64data: str) -> bytes:
    return base64.b64decode(b64data)


APP_TITLE   = "Valhalla Flasher — NerdQaxe++ Hydro"
APP_VERSION = "2.1.0"
CHIP        = "esp32s3"
FLASH_BAUD  = "460800"
WWW_OFFSET   = "0x290000"
MINER_OFFSET = "0x10000"
RELOAD_PAUSE  = 8
OTA_TIMEOUT   = 120
OTA_WAIT_BOOT = 20




# ── Triquetra corner drawn as SVG paths on a Canvas ──────────────
# The triquetra (trinity knot) is rendered entirely in Tkinter Canvas
# arcs and lines — no external image needed, no background.

class TriquetaCorner(tk.Label):
    """
    Displays the triquetra image (PNG with transparent background) as a corner widget.
    flip_x / flip_y mirror it for all four corners.
    The image is tinted gold to match the app palette.
    Requires: Pillow (pip install pillow) and triquetra_transparent.png in assets/.
    """
    _cache: dict = {}   # class-level image cache keyed by (size, flip_x, flip_y)

    def __init__(self, parent, size: int = 115,
                 flip_x: bool = False, flip_y: bool = False, **kwargs):
        super().__init__(parent, bg="#0f0a06", borderwidth=0,
                         highlightthickness=0, **kwargs)
        key = (size, flip_x, flip_y)
        if key not in TriquetaCorner._cache:
            TriquetaCorner._cache[key] = self._make_photo(size, flip_x, flip_y)
        self._photo = TriquetaCorner._cache[key]
        self.configure(image=self._photo, width=size, height=size)

    @staticmethod
    def _make_photo(size: int, flip_x: bool, flip_y: bool):
        """Load, tint gold, resize, flip and convert to PhotoImage."""
        from PIL import Image, ImageOps, ImageEnhance
        import numpy as np

        img = Image.open(_io.BytesIO(_asset_bytes(_TRIQUETRA_PNG_B64))).convert("RGBA")

        # Tint black symbol pixels to warm gold (#d4a74f)
        data = np.array(img, dtype=np.float32)
        gold = np.array([212, 167, 79], dtype=np.float32)   # #d4a74f
        # Alpha mask: where original pixel is dark (symbol)
        alpha = data[:, :, 3:4] / 255.0
        symbol_mask = 1.0 - (data[:, :, :3].mean(axis=2, keepdims=True) / 255.0)
        # Blend: symbol→gold, rest stays transparent
        tinted = gold * symbol_mask + data[:, :, :3] * (1.0 - symbol_mask)
        tinted = np.clip(tinted, 0, 255).astype(np.uint8)
        data[:, :, :3] = tinted
        img = Image.fromarray(data.astype(np.uint8), "RGBA")

        # Resize to target size with high quality
        img = img.resize((size, size), Image.LANCZOS)

        # Apply flips
        if flip_x:
            img = ImageOps.mirror(img)
        if flip_y:
            img = ImageOps.flip(img)

        # Composite onto dark background matching app BG
        bg = Image.new("RGBA", (size, size), (15, 10, 6, 255))   # #0f0a06
        bg.paste(img, (0, 0), img)
        final = bg.convert("RGB")

        # Return as Tkinter-compatible PhotoImage
        from PIL import ImageTk
        return ImageTk.PhotoImage(final)


# ── Main application ─────────────────────────────────────────────
class ValhallaFlasher:

    BG        = "#0f0a06"
    CARD_BG   = "#1a120b"
    STATUS_BG = "#24170d"
    LOG_BG    = "#120c08"
    FG_GOLD   = "#f0d38b"
    FG_WARM   = "#e7d5b1"
    FG_DIM    = "#8f7851"
    FG_MUTED  = "#d8c29a"
    BORDER    = "#7a4b17"

    MODE_SERIAL  = "serial"
    MODE_NETWORK = "network"

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(f"{APP_TITLE}  v{APP_VERSION}")
        self.root.geometry("1040x840")
        self.root.minsize(920, 720)
        self.root.configure(bg=self.BG)

        try:
            _ico_tmp = _tempfile.NamedTemporaryFile(suffix=".ico", delete=False)
            _ico_tmp.write(_asset_bytes(_VALHALLA_ICO_B64))
            _ico_tmp.close()
            self.root.iconbitmap(_ico_tmp.name)
        except Exception:
            pass

        self.log_queue  = queue.Queue()
        self.is_busy    = False
        self.flash_mode = tk.StringVar(value=self.MODE_NETWORK)

        self.port_var   = tk.StringVar()
        self.ip_var     = tk.StringVar(value="192.168.1.")
        self.www_var    = tk.StringVar()
        self.miner_var  = tk.StringVar()
        self.status_var = tk.StringVar(value="Choose a flash mode, then select your firmware files.")

        self._setup_style()
        self._build_ui()
        self._refresh_ports()
        self._on_mode_change()
        self._poll()

        self._log(f"{APP_TITLE} v{APP_VERSION} — the forge is ready.")
        self._log("Network (OTA): POST /api/system/OTAWWW  →  /api/system/OTA")
        self._log("Serial: esptool write_flash at configured offsets")

    def _setup_style(self):
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except Exception:
            pass
        bg, card = self.BG, self.CARD_BG
        st.configure("V.TFrame",       background=bg)
        st.configure("Card.TFrame",    background=card)
        st.configure("Title.TLabel",   background=bg,   foreground="#f4d58d", font=("Georgia", 26, "bold"))
        st.configure("Sub.TLabel",     background=bg,   foreground="#c8a96b", font=("Segoe UI", 11, "italic"))
        st.configure("Section.TLabel", background=card, foreground=self.FG_GOLD, font=("Segoe UI", 12, "bold"))
        st.configure("Gold.TButton",
                     font=("Segoe UI", 11, "bold"), padding=(14, 8),
                     background="#7a4b17", foreground=self.FG_GOLD)
        st.map("Gold.TButton",
               background=[("active", "#d4a74f"), ("disabled", "#2a1a0a")],
               foreground=[("disabled", "#5a4530")])
        st.configure("Gold.Horizontal.TProgressbar",
                     troughcolor="#2a1b10", background="#d4a74f",
                     bordercolor="#7a4b17", lightcolor="#e8c96a",
                     darkcolor="#a06820", thickness=20)
        st.configure("TEntry",
                     fieldbackground="#26190f", foreground=self.FG_WARM,
                     insertcolor=self.FG_WARM, bordercolor="#5e3a16")
        st.configure("TCombobox",
                     fieldbackground="#26190f", foreground=self.FG_WARM,
                     selectbackground="#3a2210")
        st.map("TCombobox",
               fieldbackground=[("readonly", "#26190f")],
               foreground=[("readonly", self.FG_WARM)])
        st.configure("TScrollbar",
                     background="#2c1d10", troughcolor="#1a120b",
                     arrowcolor=self.FG_GOLD, bordercolor="#3a2210")
        st.configure("Mode.TRadiobutton",
                     background="#160e07", foreground=self.FG_GOLD,
                     font=("Segoe UI", 11, "bold"), indicatorcolor="#d4a74f")
        st.map("Mode.TRadiobutton",
               background=[("active", "#1e1208")],
               foreground=[("active", "#f2d792")])

    def _build_ui(self):
        main = ttk.Frame(self.root, style="V.TFrame", padding=16)
        main.pack(fill="both", expand=True)

        # ── Header ────────────────────────────────────────────────
        header = ttk.Frame(main, style="V.TFrame")
        header.pack(fill="x", pady=(0, 6))

        TriquetaCorner(header, size=115).pack(side="left")

        cw = ttk.Frame(header, style="V.TFrame")
        cw.pack(side="left", fill="x", expand=True, padx=16)
        ttk.Label(cw, text="VALHALLA FLASHER", style="Title.TLabel").pack(anchor="center")
        ttk.Label(cw, text=f"NerdQaxe++ Hydro  ·  ESP32-S3 Forge  ·  v{APP_VERSION}",
                  style="Sub.TLabel").pack(anchor="center", pady=(3, 0))
        tk.Label(cw, text="Programming by Alan Klusacek",
                 bg=self.BG, fg="#FFD700",
                 font=("Segoe UI", 10, "bold")).pack(anchor="center", pady=(6, 0))
        tk.Label(cw, text="sonofgrimnir@outlook.com",
                 bg=self.BG, fg="#FFD700",
                 font=("Segoe UI", 9, "italic")).pack(anchor="center", pady=(1, 0))

        TriquetaCorner(header, size=115, flip_x=True).pack(side="right")

        tk.Frame(main, bg="#7a4b17", height=2).pack(fill="x", pady=(0, 8))

        # ── Main card ─────────────────────────────────────────────
        card = tk.Frame(main, bg=self.CARD_BG,
                        highlightbackground=self.BORDER, highlightthickness=2)
        card.pack(fill="both", expand=True, padx=4, pady=4)

        # Mode selector
        mf = tk.Frame(card, bg="#160e07",
                      highlightbackground="#5e3a16", highlightthickness=1)
        mf.pack(fill="x", padx=18, pady=(14, 0))
        tk.Label(mf, text="⚔  Flash Mode", bg="#160e07",
                 fg=self.FG_GOLD, font=("Segoe UI", 11, "bold"),
                 padx=14, pady=8).pack(side="left")
        ttk.Radiobutton(mf, text="🌐  Network / OTA  (WiFi · recommended)",
                        variable=self.flash_mode, value=self.MODE_NETWORK,
                        style="Mode.TRadiobutton",
                        command=self._on_mode_change).pack(side="left", padx=(0, 24), pady=8)
        ttk.Radiobutton(mf, text="🔌  Serial / USB  (first-time · recovery)",
                        variable=self.flash_mode, value=self.MODE_SERIAL,
                        style="Mode.TRadiobutton",
                        command=self._on_mode_change).pack(side="left", pady=8)

        # Network section
        self.net_frame = tk.Frame(card, bg=self.CARD_BG)
        self.net_frame.pack(fill="x", padx=18, pady=(10, 0))
        self.net_frame.grid_columnconfigure(1, weight=1)
        self._label(self.net_frame, 0, "Miner IP address")
        ip_inner = tk.Frame(self.net_frame, bg=self.CARD_BG)
        ip_inner.grid(row=0, column=1, sticky="ew", pady=6)
        ip_inner.grid_columnconfigure(0, weight=1)
        self.ip_entry = ttk.Entry(ip_inner, textvariable=self.ip_var)
        self.ip_entry.grid(row=0, column=0, sticky="ew")
        self.ping_btn = ttk.Button(ip_inner, text="Ping miner", style="Gold.TButton",
                                   command=self._ping_miner)
        self.ping_btn.grid(row=0, column=1, padx=(10, 0))
        tk.Label(self.net_frame,
                 text="Enter miner IP from the OLED screen.  "
                      "API: /api/system/OTAWWW → /api/system/OTA → /api/system/restart",
                 bg=self.CARD_BG, fg=self.FG_DIM, font=("Segoe UI", 9)
                 ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 4))

        # Serial section
        self.ser_frame = tk.Frame(card, bg=self.CARD_BG)
        self.ser_frame.pack(fill="x", padx=18, pady=(0, 0))
        self.ser_frame.grid_columnconfigure(1, weight=1)
        self._label(self.ser_frame, 0, "Serial port")
        self.port_combo = ttk.Combobox(self.ser_frame, textvariable=self.port_var, state="readonly")
        self.port_combo.grid(row=0, column=1, sticky="ew", pady=6, padx=(0, 8))
        self.refresh_btn = ttk.Button(self.ser_frame, text="⟳  Refresh",
                                      style="Gold.TButton", command=self._refresh_ports)
        self.refresh_btn.grid(row=0, column=2, pady=6)
        tk.Label(self.ser_frame,
                 text=f"Offsets: www.bin → {WWW_OFFSET}   esp-miner.bin → {MINER_OFFSET}   "
                      f"Baud: {FLASH_BAUD}   Chip: {CHIP}",
                 bg=self.CARD_BG, fg=self.FG_DIM, font=("Segoe UI", 9)
                 ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 4))

        tk.Frame(card, bg="#3a2210", height=1).pack(fill="x", padx=18, pady=(6, 0))

        # File pickers
        ff = tk.Frame(card, bg=self.CARD_BG)
        ff.pack(fill="x", padx=18, pady=(8, 0))
        ff.grid_columnconfigure(1, weight=1)
        self._file_row(ff, 0, "www.bin",       self.www_var,   self._browse_www)
        self._file_row(ff, 1, "esp-miner.bin", self.miner_var, self._browse_miner)

        # Action buttons
        bf = tk.Frame(card, bg=self.CARD_BG)
        bf.pack(fill="x", padx=18, pady=(12, 14))
        self.flash_btn = ttk.Button(bf, text="⚡  Begin Flashing",
                                    style="Gold.TButton", command=self._start_flash)
        self.flash_btn.pack(side="left", padx=(0, 10))
        self.erase_btn = ttk.Button(bf, text="🔥  Erase Flash  (serial only)",
                                    style="Gold.TButton", command=self._erase_flash)
        self.erase_btn.pack(side="left", padx=(0, 10))
        self.reboot_btn = ttk.Button(bf, text="↺  Reboot Only",
                                     style="Gold.TButton", command=self._reboot_only)
        self.reboot_btn.pack(side="left")

        # Progress
        self.progress = ttk.Progressbar(card, maximum=100, mode="determinate",
                                        style="Gold.Horizontal.TProgressbar")
        self.progress.pack(fill="x", padx=18, pady=(0, 8))

        # Status
        sf = tk.Frame(card, bg=self.STATUS_BG,
                      highlightbackground="#5e3a16", highlightthickness=1)
        sf.pack(fill="x", padx=18, pady=(0, 10))
        tk.Label(sf, textvariable=self.status_var, bg=self.STATUS_BG, fg=self.FG_GOLD,
                 font=("Segoe UI", 10, "bold"), padx=14, pady=10, anchor="w").pack(fill="x")

        # Log
        ttk.Label(card, text="Runes of the forge", style="Section.TLabel").pack(anchor="w", padx=18)
        lw = tk.Frame(card, bg=self.CARD_BG)
        lw.pack(fill="both", expand=True, padx=18, pady=(6, 14))
        self.log_text = tk.Text(lw, bg=self.LOG_BG, fg=self.FG_WARM,
                                insertbackground=self.FG_WARM,
                                selectbackground="#3a2a14",
                                relief="flat", wrap="word",
                                font=("Consolas", 10), padx=12, pady=12)
        self.log_text.pack(side="left", fill="both", expand=True)
        sc = ttk.Scrollbar(lw, orient="vertical", command=self.log_text.yview)
        sc.pack(side="right", fill="y")
        self.log_text.configure(yscrollcommand=sc.set)
        self.log_text.tag_config("info",    foreground=self.FG_WARM)
        self.log_text.tag_config("success", foreground="#7ecf7e")
        self.log_text.tag_config("warning", foreground="#d4a74f")
        self.log_text.tag_config("error",   foreground="#e86f6f")
        self.log_text.tag_config("dim",     foreground=self.FG_DIM)
        self.log_text.tag_config("net",     foreground="#7eb8d4")

        # Footer
        tk.Frame(main, bg="#7a4b17", height=2).pack(fill="x", pady=(4, 0))
        footer = ttk.Frame(main, style="V.TFrame")
        footer.pack(fill="x")
        TriquetaCorner(footer, size=90, flip_y=True).pack(side="left")
        tk.Label(footer,
                 text=f"Network OTA: /api/system/OTAWWW + /api/system/OTA  ·  "
                      f"Serial: esptool {CHIP}  ·  Python {sys.version.split()[0]}",
                 bg=self.BG, fg=self.FG_DIM, font=("Segoe UI", 9)).pack(side="left", expand=True)
        TriquetaCorner(footer, size=90, flip_x=True, flip_y=True).pack(side="right")

    # ── Helpers ──────────────────────────────────────────────────
    def _label(self, parent, row, text):
        tk.Label(parent, text=text, bg=self.CARD_BG, fg=self.FG_GOLD,
                 font=("Segoe UI", 10, "bold")).grid(
            row=row, column=0, sticky="w", padx=(0, 12), pady=6)

    def _file_row(self, parent, row, label, var, cmd):
        self._label(parent, row, label)
        ttk.Entry(parent, textvariable=var).grid(row=row, column=1, sticky="ew", pady=6, padx=(0, 8))
        ttk.Button(parent, text="Browse…", style="Gold.TButton",
                   command=cmd).grid(row=row, column=2, pady=6)

    def _browse_www(self):
        p = filedialog.askopenfilename(title="Select www.bin",
                                       filetypes=[("BIN files", "*.bin"), ("All", "*.*")])
        if p: self.www_var.set(p)

    def _browse_miner(self):
        p = filedialog.askopenfilename(title="Select esp-miner.bin",
                                       filetypes=[("BIN files", "*.bin"), ("All", "*.*")])
        if p: self.miner_var.set(p)

    def _on_mode_change(self):
        mode = self.flash_mode.get()
        if mode == self.MODE_NETWORK:
            self.net_frame.pack(fill="x", padx=18, pady=(10, 0), before=self.ser_frame)
            self.ser_frame.pack_forget()
        else:
            self.net_frame.pack_forget()
            self.ser_frame.pack(fill="x", padx=18, pady=(10, 0))
        self._log(f"Mode: {'Network OTA' if mode == self.MODE_NETWORK else 'Serial USB'}", "dim")

    def _refresh_ports(self):
        ports = self._list_ports()
        self.port_combo["values"] = ports
        if ports:
            if self.port_var.get() not in ports:
                self.port_var.set(ports[0])
            self._log("Detected ports: " + ", ".join(ports))
        else:
            self.port_var.set("")
            self._log("No serial ports detected.", "warning")

    def _list_ports(self):
        try:
            import serial.tools.list_ports
            return [p.device for p in serial.tools.list_ports.comports()]
        except Exception:
            if os.name == "nt":
                return [f"COM{i}" for i in range(1, 33)]
            import glob
            return sorted(glob.glob("/dev/ttyUSB*") + glob.glob("/dev/ttyACM*") + glob.glob("/dev/cu.*"))

    def _ping_miner(self):
        ip = self.ip_var.get().strip()
        if not ip:
            messagebox.showerror("No IP", "Enter the miner's IP address first.")
            return
        threading.Thread(target=self._ping_worker, args=(ip,), daemon=True).start()

    def _ping_worker(self, ip):
        url = f"http://{ip}/api/system/info"
        self._enqueue("log", (f"Pinging {url} …", "net"))
        self._enqueue("status", f"Pinging {ip}…")
        try:
            resp = urllib.request.urlopen(url, timeout=5)
            data = resp.read(512).decode(errors="replace")
            self._enqueue("log", (f"Miner alive: {data[:200]}", "success"))
            self._enqueue("status", f"Miner at {ip} is alive ✓")
        except Exception as e:
            self._enqueue("log", (f"Ping failed: {e}", "error"))
            self._enqueue("status", f"Cannot reach {ip} — check IP and WiFi.")

    def _log(self, msg: str, tag: str = "info"):
        stamp = time.strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{stamp}] {msg}\n", tag)
        self.log_text.see("end")
        self.log_text.update_idletasks()

    def _enqueue(self, kind: str, value):
        self.log_queue.put((kind, value))

    def _poll(self):
        try:
            while True:
                kind, value = self.log_queue.get_nowait()
                if kind == "log":
                    self._log(value[0], value[1] if len(value) > 1 else "info")
                elif kind == "status":
                    self.status_var.set(value)
                elif kind == "progress":
                    self.progress["value"] = value
                elif kind == "done":
                    self.is_busy = False
                    self._set_controls(True)
        except queue.Empty:
            pass
        self.root.after(100, self._poll)

    def _set_controls(self, enabled: bool):
        s  = "normal"   if enabled else "disabled"
        cs = "readonly" if enabled else "disabled"
        self.flash_btn.configure(state=s)
        self.erase_btn.configure(state=s)
        self.reboot_btn.configure(state=s)
        self.ping_btn.configure(state=s)
        self.refresh_btn.configure(state=s)
        self.port_combo.configure(state=cs)

    def _validate(self, need_files=True) -> bool:
        mode = self.flash_mode.get()
        if mode == self.MODE_NETWORK:
            ip = self.ip_var.get().strip()
            if not ip or ip == "192.168.1.":
                messagebox.showerror("No IP", "Enter the miner IP address.")
                return False
        else:
            if not self.port_var.get():
                messagebox.showerror("No port", "Choose a serial port first.")
                return False
        if need_files:
            if not os.path.isfile(self.www_var.get()):
                messagebox.showerror("www.bin missing", "Browse to a valid www.bin.")
                return False
            if not os.path.isfile(self.miner_var.get()):
                messagebox.showerror("esp-miner.bin missing", "Browse to a valid esp-miner.bin.")
                return False
        return True

    # ── Actions ──────────────────────────────────────────────────
    def _start_flash(self):
        if self.is_busy or not self._validate(True): return
        self.is_busy = True
        self._set_controls(False)
        self.progress["value"] = 0
        if self.flash_mode.get() == self.MODE_NETWORK:
            threading.Thread(target=self._ota_worker, daemon=True).start()
        else:
            threading.Thread(target=self._serial_flash_worker, daemon=True).start()

    def _erase_flash(self):
        if self.is_busy or not self._validate(False): return
        if self.flash_mode.get() == self.MODE_NETWORK:
            messagebox.showinfo("Serial only", "Erase Flash requires Serial mode.")
            return
        if not messagebox.askyesno("Erase flash?",
                                   f"Erase ALL flash on {self.port_var.get()}?\nThis cannot be undone."):
            return
        self.is_busy = True
        self._set_controls(False)
        threading.Thread(target=self._erase_worker, daemon=True).start()

    def _reboot_only(self):
        if self.is_busy or not self._validate(False): return
        self.is_busy = True
        self._set_controls(False)
        if self.flash_mode.get() == self.MODE_NETWORK:
            threading.Thread(target=self._ota_reboot_worker, daemon=True).start()
        else:
            threading.Thread(target=self._serial_reboot_worker, daemon=True).start()

    # ── OTA workers ──────────────────────────────────────────────
    def _ota_post(self, ip, endpoint, filepath, label):
        url = f"http://{ip}{endpoint}"
        self._enqueue("log", (f"→ POST {url}  ({os.path.basename(filepath)})", "net"))
        with open(filepath, "rb") as fh:
            data = fh.read()
        self._enqueue("log", (f"  Uploading {len(data)/1024:.1f} KB …", "net"))
        req = urllib.request.Request(url, data=data, method="POST",
                                     headers={"Content-Type": "application/octet-stream",
                                              "Content-Length": str(len(data))})
        try:
            resp = urllib.request.urlopen(req, timeout=OTA_TIMEOUT)
            body = resp.read(512).decode(errors="replace")
            self._enqueue("log", (f"  HTTP {resp.status}: {body[:120]}", "success"))
        except urllib.error.HTTPError as e:
            body = e.read(512).decode(errors="replace")
            raise RuntimeError(f"{label} HTTP {e.code}: {body[:200]}")

    def _ota_wait_online(self, ip, timeout=OTA_WAIT_BOOT):
        url = f"http://{ip}/api/system/info"
        self._enqueue("log", (f"  Waiting for miner web server (up to {timeout}s)…", "net"))
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                urllib.request.urlopen(url, timeout=3)
                self._enqueue("log", ("  Miner web server is back up ✓", "success"))
                return
            except Exception:
                time.sleep(2)
        self._enqueue("log", ("  Timeout waiting for web server — continuing.", "warning"))

    def _ota_worker(self):
        ip = self.ip_var.get().strip()
        www_file = self.www_var.get()
        miner_file = self.miner_var.get()
        try:
            self._enqueue("status", "Opening the OTA gates of Valhalla…")
            self._enqueue("log", (f"Target: http://{ip}", "net"))
            self._enqueue("progress", 5)

            self._enqueue("status", "Step 1/3 — Uploading www.bin…")
            self._ota_post(ip, "/api/system/OTAWWW", www_file, "www.bin OTA")
            self._enqueue("progress", 38)
            self._enqueue("log", ("www.bin upload complete.", "success"))

            self._enqueue("status", f"Step 2/3 — Waiting {OTA_WAIT_BOOT}s for reload…")
            time.sleep(3)
            self._ota_wait_online(ip, OTA_WAIT_BOOT)
            self._enqueue("progress", 55)

            self._enqueue("status", "Step 3/3 — Uploading esp-miner.bin…")
            self._ota_post(ip, "/api/system/OTA", miner_file, "esp-miner.bin OTA")
            self._enqueue("progress", 90)
            self._enqueue("log", ("esp-miner.bin upload complete — miner rebooting.", "success"))

            time.sleep(2)
            try:
                req = urllib.request.Request(f"http://{ip}/api/system/restart", data=b"", method="POST")
                urllib.request.urlopen(req, timeout=5)
                self._enqueue("log", ("Restart command sent.", "net"))
            except Exception:
                pass  # expected — miner already rebooting

            self._enqueue("progress", 100)
            self._enqueue("log", ("The miner rises anew. Skål! ⚡", "success"))
            self._enqueue("status", "OTA flash complete ✓ — NerdQaxe++ Hydro rebooting.")
            self.root.after(0, lambda: messagebox.showinfo(
                "Valhalla — OTA Complete",
                "Both binaries uploaded successfully.\nNerdQaxe++ Hydro is rebooting."
            ))
        except Exception as exc:
            self._enqueue("log",    (f"OTA FAILED: {exc}", "error"))
            self._enqueue("status", f"OTA failed: {exc}")
            self.root.after(0, lambda: messagebox.showerror("OTA failed", str(exc)))
        finally:
            self._enqueue("done", None)

    def _ota_reboot_worker(self):
        ip = self.ip_var.get().strip()
        try:
            self._enqueue("status", "Sending restart via API…")
            url = f"http://{ip}/api/system/restart"
            self._enqueue("log", (f"→ POST {url}", "net"))
            req = urllib.request.Request(url, data=b"", method="POST")
            urllib.request.urlopen(req, timeout=8)
            self._enqueue("log",    ("Restart accepted.", "success"))
            self._enqueue("status", "Restart command sent ✓")
        except Exception as exc:
            self._enqueue("log",    (f"Restart failed: {exc}", "error"))
            self._enqueue("status", f"Restart failed: {exc}")
            self.root.after(0, lambda: messagebox.showerror("Restart failed", str(exc)))
        finally:
            self._enqueue("done", None)

    # ── Serial workers ───────────────────────────────────────────
    def _base_cmd(self, port):
        return [sys.executable, "-m", "esptool",
                "--chip", CHIP, "--port", port, "--baud", FLASH_BAUD]

    def _run_cmd(self, cmd, label):
        self._enqueue("log", (f"→ {label}: {' '.join(cmd)}", "dim"))
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, bufsize=1)
        for line in proc.stdout:
            s = line.rstrip()
            tag = "warning" if "warning" in s.lower() else \
                  "error"   if "error"   in s.lower() else "info"
            self._enqueue("log", (s, tag))
        proc.wait()
        if proc.returncode != 0:
            raise RuntimeError(f"{label} failed (exit {proc.returncode})")

    def _serial_flash_worker(self):
        port = self.port_var.get()
        www_file = self.www_var.get()
        miner_file = self.miner_var.get()
        try:
            self._enqueue("status", "Opening serial gates of Valhalla…")
            self._enqueue("log", (f"Port: {port}  Baud: {FLASH_BAUD}", "dim"))
            self._enqueue("progress", 5)

            self._enqueue("status", "Step 1/3 — Flashing www.bin…")
            self._run_cmd(self._base_cmd(port) + [
                "--before", "default-reset", "--after", "no-reset",
                "write_flash", WWW_OFFSET, www_file
            ], "www.bin flash")
            self._enqueue("progress", 42)
            self._enqueue("log", ("www.bin flashed.", "success"))

            self._enqueue("status", f"Step 2/3 — Reload pause ({RELOAD_PAUSE}s)…")
            for sec in range(RELOAD_PAUSE, 0, -1):
                self._enqueue("log", (f"  Pause: {sec}s…", "dim"))
                time.sleep(1)
            self._enqueue("progress", 55)

            self._enqueue("status", "Step 3/3 — Flashing esp-miner.bin…")
            self._run_cmd(self._base_cmd(port) + [
                "--before", "default-reset", "--after", "hard-reset",
                "write_flash", MINER_OFFSET, miner_file
            ], "esp-miner.bin flash")
            self._enqueue("progress", 92)
            self._enqueue("log", ("esp-miner.bin flashed.", "success"))

            try: self._run_cmd(self._base_cmd(port) + ["run"], "reboot")
            except Exception: pass

            self._enqueue("progress", 100)
            self._enqueue("log", ("Miner reborn from the forge. Skål!", "success"))
            self._enqueue("status", "Serial flash complete ✓ — NerdQaxe++ Hydro rebooted.")
            self.root.after(0, lambda: messagebox.showinfo(
                "Valhalla — Flash Complete",
                "Serial flash successful.\nNerdQaxe++ Hydro is rebooting."
            ))
        except Exception as exc:
            self._enqueue("log",    (f"FLASH FAILED: {exc}", "error"))
            self._enqueue("status", f"Failed: {exc}")
            self.root.after(0, lambda: messagebox.showerror("Flash failed", str(exc)))
        finally:
            self._enqueue("done", None)

    def _erase_worker(self):
        port = self.port_var.get()
        try:
            self._enqueue("status", "Erasing flash…")
            self._run_cmd(self._base_cmd(port) + ["erase_flash"], "erase_flash")
            self._enqueue("log",    ("Flash erased.", "success"))
            self._enqueue("status", "Flash erase complete.")
        except Exception as exc:
            self._enqueue("log",    (f"ERASE FAILED: {exc}", "error"))
            self._enqueue("status", f"Erase failed: {exc}")
            self.root.after(0, lambda: messagebox.showerror("Erase failed", str(exc)))
        finally:
            self._enqueue("done", None)

    def _serial_reboot_worker(self):
        port = self.port_var.get()
        try:
            self._enqueue("status", "Sending reboot via serial…")
            try: self._run_cmd(self._base_cmd(port) + ["run"], "reboot")
            except Exception: self._run_cmd(self._base_cmd(port) + ["chip_id"], "reset fallback")
            self._enqueue("log",    ("Reboot sent.", "success"))
            self._enqueue("status", "Reboot sent ✓")
        except Exception as exc:
            self._enqueue("log",    (f"REBOOT FAILED: {exc}", "error"))
            self._enqueue("status", f"Reboot failed: {exc}")
            self.root.after(0, lambda: messagebox.showerror("Reboot failed", str(exc)))
        finally:
            self._enqueue("done", None)


def main():
    root = tk.Tk()
    ValhallaFlasher(root)
    root.mainloop()


if __name__ == "__main__":
    main()
