
# file:5 is the updated one — need to read it differently
# Let's check which file on disk has the gold labels
import glob
for f in glob.glob("./*.py") + glob.glob("/tmp/*.py"):
    with open(f, "r", encoding="utf-8") as fh:
        content = fh.read()
    if "Programming by Alan Klusacek" in content:
        print(f"Found gold labels in: {f} ({len(content)} chars)")
