
# 5. Also add gold labels if not present (should already be there)
print("Gold labels present:", "Programming by Alan Klusacek" in new_src)

# 6. Write final file
out_path = "/tmp/valhalla_flasher_standalone.py"
with open(out_path, "w", encoding="utf-8") as f:
    f.write(new_src)

print(f"Written: {out_path} ({len(new_src)} chars)")

# Quick sanity checks
checks = [
    ("Gold labels",        "Programming by Alan Klusacek"),
    ("Email label",        "sonofgrimnir@outlook.com"),
    ("Base64 PNG",         "_TRIQUETRA_PNG_B64"),
    ("Base64 ICO",         "_VALHALLA_ICO_B64"),
    ("asset_bytes helper", "_asset_bytes("),
    ("BytesIO load",       "_io.BytesIO(_asset_bytes("),
    ("tempfile ICO",       "_ico_tmp = _tempfile.NamedTemporaryFile"),
    ("No resource_path",   "resource_path" not in new_src),
    ("No img_path",        "img_path" not in new_src),
])
for label, check in checks:
    if isinstance(check, bool):
        status = "✓" if check else "✗ FAIL"
    else:
        status = "✓" if check in new_src else "✗ FAIL"
    print(f"  {status}  {label}")
