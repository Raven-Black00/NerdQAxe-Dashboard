
# Use /tmp/valhalla_flasher.py — already has gold labels
with open("/tmp/valhalla_flasher.py", "r", encoding="utf-8") as f:
    src = f.read()

print(f"Source: {len(src)} chars")
print("Gold labels:", "Programming by Alan Klusacek" in src)
print("iconbitmap:", "iconbitmap" in src)
print("img_path resource_path:", "img_path = resource_path" in src)
