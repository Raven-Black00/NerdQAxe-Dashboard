
out_path = "/tmp/valhalla_flasher_standalone.py"
with open(out_path, "w", encoding="utf-8") as f:
    f.write(new_src)

print(f"Written: {out_path} ({len(new_src)} chars)")

checks = [
    ("Gold labels",         "Programming by Alan Klusacek"),
    ("Email label",         "sonofgrimnir@outlook.com"),
    ("Base64 PNG",          "_TRIQUETRA_PNG_B64"),
    ("Base64 ICO",          "_VALHALLA_ICO_B64"),
    ("asset_bytes helper",  "_asset_bytes("),
    ("BytesIO load",        "_io.BytesIO(_asset_bytes("),
    ("tempfile ICO",        "_ico_tmp = _tempfile.NamedTemporaryFile"),
]
for label, check in checks:
    status = "✓" if check in new_src else "✗ FAIL"
    print(f"  {status}  {label}")

# Negative checks
print("  ✓  No resource_path" if "resource_path" not in new_src else "  ✗ FAIL  resource_path still present")
print("  ✓  No img_path"      if "img_path" not in new_src      else "  ✗ FAIL  img_path still present")
